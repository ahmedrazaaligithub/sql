const myObj = {
    name:'shehzad',
    age:22,
    country:'pakistan',
    hobbies:['coding'],
    teacher:{name:'Sir Inzamam'}
}