
var userName = "Bilal Raza";
var userAge = 20;
var isUserActive = false;
var userFavDishes = [
    { name: "Biryani", location: "Naseeb" },
];
var userParentInfo = {
    fatherName: "ABC",
    motherName: "ABC",
};
userName = "12";
