

// 1. TypeScript is a typed superset of JavaScript.

// 2. TypeScript is a superset of JavaScript.

const userName: string = "M.Mahad Siidiqui"

console.log(userName)